<?php
// Heading
$_['heading_title']     = 'Variações';

// Text
$_['text_success']      = 'Modulo modificado com sucesso';
$_['text_list']         = 'Listando variações';
$_['text_add']          = 'Adicionar';
$_['text_edit']         = 'Editar';

// Column
$_['column_variant']      = 'Variação';
$_['column_action']       = 'Ação';

// Entry
$_['entry_description']    	= 'Descrição da variação (visivel para o cliente na loja)';
$_['entry_code']        	  = 'Descrição da Variação (visivel na edição do produto';

$_['entry_related_variant_type'] = 'Nome da variação';
$_['entry_related_variant_name'] = 'Nome da variação';
$_['entry_related_variant']      = 'Produtos nesse conjunto';

$_['help_related_variant_name']  = 'Rótulo da variação visivel para o cliente na loja';
$_['help_related_variant']       = 'Products for the variant.';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify variants!';
