<?php
// Heading
$_['heading_title']     = 'Variações';

// Text
$_['text_success']      = 'Success: You have modified variants!';
$_['text_list']         = 'Lista';
$_['text_add']          = 'Adicionar';
$_['text_edit']         = 'Editar';

// Column
$_['column_variant']      = 'Variação';
$_['column_action']       = 'Ação';

// Entry
$_['entry_description']    = 'Descrição da variação';
$_['entry_code']        	 = 'Código da variaçõa';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify variants!';
